# -----------------------------------------------------------
# Pakete prüfen und ggf. installieren
# -----------------------------------------------------------
req <- c("yacca","CCA","CCP","ggplot2","reshape2")  # Liste benötigter Pakete

# Prüfen, welche Pakete noch nicht installiert sind
inst <- req[!(req %in% installed.packages()[, "Package"])]

# Falls es fehlende Pakete gibt, diese installieren (inklusive Abhängigkeiten)
if (length(inst) > 0) install.packages(inst, dependencies = TRUE)

# -----------------------------------------------------------
# Externe Skripte einbinden und ausführen
# -----------------------------------------------------------
# Dieses Skript führt zuerst Datenaufbereitung und Bereinigung aus
source("code/01_setup_and_cleaning.R")

# Danach werden die kanonischen Korrelationsanalysen durchgeführt
source("code/02_cca_models.R")

# -----------------------------------------------------------
# Abschlussmeldung
# -----------------------------------------------------------
# Hinweis für den Benutzer, wo die erzeugten Abbildungen und Tabellen gespeichert wurden
message("Fertig. Abbildungen unter outputs/figures/, Tabellen unter outputs/tables/.")
