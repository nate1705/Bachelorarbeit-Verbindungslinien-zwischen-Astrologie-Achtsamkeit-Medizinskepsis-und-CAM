# -----------------------------------------------------------
# Lade benötigte R-Pakete
# -----------------------------------------------------------
library(yacca)     # Paket für kanonische Korrelationsanalyse (CCA)
library(CCA)       # weiteres Paket für CCA-Funktionen
library(CCP)       # Paket für Signifikanztests der CCA
library(ggplot2)   # Paket zur Datenvisualisierung

# -----------------------------------------------------------
# Verzeichnisse für Ausgaben (Grafiken und Tabellen) anlegen
# -----------------------------------------------------------
out_fig <- "outputs/figures"  # Pfad für Figuren
out_tab <- "outputs/tables"   # Pfad für Tabellen
if (!dir.exists(out_fig)) dir.create(out_fig, recursive = TRUE)  # Erstellen, falls nicht vorhanden
if (!dir.exists(out_tab)) dir.create(out_tab, recursive = TRUE)

# -----------------------------------------------------------
# Daten einlesen (falls das Dataframe df noch nicht existiert)
# -----------------------------------------------------------
if (!exists("df")) {
  df <- read.csv(file.path("data","raw","Daten_Fragebogen_aktuell.csv"), stringsAsFactors = FALSE)
  
  # Umwandlung aller Spalten in numerische Werte (falls möglich)
  # SuppressWarnings verhindert unnötige Warnungen bei NAs
  df[] <- lapply(df, function(x) suppressWarnings(as.numeric(as.character(x))))
}

# -----------------------------------------------------------
# Hilfsfunktionen
# -----------------------------------------------------------

# Funktion: Spalten auswählen, die bestimmte Keywords enthalten
get_cols <- function(keywords) {
  matches <- sapply(keywords, function(k) grep(k, names(df), ignore.case = TRUE, value = TRUE))
  df[, unique(unlist(matches)), drop = FALSE]  # Rückgabe der ausgewählten Spalten
}

# Funktion: konstante Spalten (ohne Varianz) entfernen
drop_const_cols <- function(d) d[, sapply(d, function(x) length(unique(na.omit(x))) > 1), drop = FALSE]

# -----------------------------------------------------------
# Variablenlabels aus Codebook laden
# (enthält wahrscheinlich Variablennamen + Kurzlabels)
# -----------------------------------------------------------
label_map <- read.csv("CODEBOOK.csv", stringsAsFactors = FALSE)

# ===========================================================
# ABSCHNITT 1: Zusammenhang zwischen Astrologie und CAM-Nutzung
# ===========================================================

# Items zu Astrologie (Prädiktor-Set A)
astrologie_items <- c(
  "X8..Ich.glaube..dass.bestimmte.astrologische.Einflüsse.eine.Bedeutung.für.das.persönliche.Wohlbefinden.haben..",
  "X9..Ich.interessiere.mich.für.astrologische.Deutungen.und.lese.gerne.über.die.Eigenschaften.meines.Sternzeichens.",
  "X10..Ich.glaube.daran..dass.astrologische.Sternzeichen.meine.Persönlichkeit.und.mein.Leben.beeinflussen.",
  "X11..Ich.bin.überzeugt..dass.Horoskope.zukünftige.Ereignisse.vorhersagen.können.",
  "X20..Ich.würde.eine.astrologische.Beratung.in.Anspruch.nehmen."
)

# Items zu CAM (Complementary and Alternative Medicine, Set B)
cam_items1 <- c(
  "X6..Ich.bin.davon.überzeugt..dass.homöopathische.Mittel.bei.der.Heilung.von.Krankheiten.helfen.können..",
  "X12..Ich.habe.bereits einen Heilpraktiker oder Heilpraktikerin aufgesucht.",
  "X13..Ich.vertraue darauf, dass Heilpraktikerinnen meinen Gesundheitszustand umfassend und ganzheitlich betrachten.",
  "X14..Bei gesundheitlichen Problemen meiner Familie ziehe ich es in Betracht, Heilpraktikerinnen hinzuzuziehen.",
  "X22..Ich.vertraue auf die Wirkung von Homöopathika, weil sie gut zu meinem achtsamen Lebensstil passen.",
  "X23..Ich würde alternative Heilmethoden oder esoterische Praktiken (Homöopathie, Chiropraktik, Kristallheilung, Pendeln etc.) bei meinen Kindern anwenden, wenn sie krank sind.",
  "X24..Ich bin offen für Behandlungen, die auf individuellen Erfahrungswerten beruhen, auch wenn sie nicht in der klassischen Medizin verbreitet sind.",
  "X25..Ich bevorzuge es, zu einer Heilpraktikerin zu gehen, anstatt konventionelle medizinische Hilfe zu suchen.",
  "X26..Ich glaube, dass Heilpraktikerinnen oft wirksamere Lösungen für gesundheitliche Probleme anbieten als Ärztinnen.",
  "X28..Ich benutze Homöopathika, weil sie leichter erhältlich sind als herkömmliche Medikamente.",
  "X30..Ich vertraue auf alternative Heilmethoden, weil ich die Erfahrung gemacht habe, dass sie wirken."
)

# Auswahl der Daten aus dem Dataframe
setA1 <- df[, astrologie_items]
setB1 <- df[, cam_items1]

# Nur vollständige Fälle (ohne fehlende Werte) behalten
cca1_data <- na.omit(cbind(setA1, setB1))

# Entfernen von konstanten Variablen (keine Varianz)
X1 <- drop_const_cols(cca1_data[, astrologie_items, drop = FALSE])
Y1 <- drop_const_cols(cca1_data[, cam_items1, drop = FALSE])

# Kanonische Korrelationsanalyse (CCA) durchführen
cca1_model <- cca(Y1, X1)
summary1 <- summary(cca1_model)   # Zusammenfassung mit Korrelationen, Chi²-Test etc.

# -----------------------------------------------------------
# Signifikanzprüfung der kanonischen Variablen (CVs)
# -----------------------------------------------------------
df1_sig <- data.frame(
  CV = names(summary1$corr),  # Namen der kanonischen Variablen
  cancor = summary1$corr,     # Korrelationen
  p.value = pchisq(summary1$chisq, df = summary1$df, lower.tail = FALSE), # p-Werte
  Signifikant = ifelse(pchisq(summary1$chisq, df = summary1$df, lower.tail = FALSE) < 0.05, "ja", "nein")
)
write.csv(df1_sig, file.path(out_tab,"cca1_signifikanz.csv"), row.names = FALSE)  # Speichern

# -----------------------------------------------------------
# Visualisierungen: Korrelationen & p-Werte
# -----------------------------------------------------------

# Balkendiagramm der kanonischen Korrelationen
p1 <- ggplot(df1_sig, aes(x = CV, y = cancor, fill = Signifikant)) +
  geom_col() + theme_minimal() +
  labs(title = "Korrelation Astrologie und CAM-Nutzung",
       x = "Kanonische Variate", y = "Korrelation (R[c])")
ggsave(file.path(out_fig,"cca1_cancor.png"), p1, width = 7, height = 5, dpi = 300)

# Liniendiagramm der p-Werte mit Signifikanzgrenze
p1b <- ggplot(df1_sig, aes(x = CV, y = p.value, group = 1)) +
  geom_point(size = 3) + geom_line() +
  geom_hline(yintercept = 0.05, linetype = "dashed", color = "red") +
  theme_minimal() +
  labs(title = "Signifikanz der CVs – Astrologie & CAM",
       x = "Kanonische Variate", y = "p-Wert")
ggsave(file.path(out_fig,"cca1_pvalues.png"), p1b, width = 7, height = 5, dpi = 300)

# -----------------------------------------------------------
# Strukturmatrix (Loadings): zeigt, welche Variablen
# am stärksten auf die erste kanonische Variable laden
# -----------------------------------------------------------
x_loadings1 <- as.data.frame(summary1$xstructcorr[, 1, drop = FALSE]); 
x_loadings1$Set <- "Astrologie"; 
x_loadings1$Variable <- rownames(x_loadings1); 
names(x_loadings1)[1] <- "Loading"

y_loadings1 <- as.data.frame(summary1$ystructcorr[, 1, drop = FALSE]); 
y_loadings1$Set <- "CAM";         
y_loadings1$Variable <- rownames(y_loadings1); 
names(y_loadings1)[1] <- "Loading"

# Zusammenführen und Labels anhängen
cv1_all_1 <- rbind(x_loadings1, y_loadings1)
cv1_all_1 <- merge(cv1_all_1, label_map, by = "Variable", all.x = TRUE)

# Visualisierung der Loadings
p1c <- ggplot(cv1_all_1, aes(x = reorder(Kurzlabel, Loading), y = Loading, fill = Set)) +
  geom_col() + coord_flip() + theme_minimal() +
  labs(title = "Kanonische Loadings: Astrologie & CAM-Nutzung", x = "", y = "Loadings")
ggsave(file.path(out_fig,"cca1_loadings_cv1.png"), p1c, width = 7, height = 7, dpi = 300)

# ===========================================================
# ABSCHNITT 2: Zusammenhang zwischen Achtsamkeit und CAM-Nutzung
# ===========================================================

# Items zu Achtsamkeit (Prädiktor-Set A)
achtsamkeit_items <- c(
  "X15..Ich.achte.in.meinem.Alltag.bewusst.auf.Achtsamkeit.und.Entspannung.",
  "X16..Ich.bin.überzeugt..dass.Achtsamkeitspraktiken.eine.heilende.Wirkung.auf.körperliche.Beschwerden.haben.können.",
  "X19..Ich.lege.großen.Wert.auf.eine.gesunde.und.bewusste.Lebensweise.",
  "X27..Ich.nehme.an.Kursen.oder.Workshops.zu.achtsamkeitsbasierten.Heilmethoden.teil..z.B..Meditation..Ayurveda..Reiki.."
)

# Items zu CAM (Set B)
cam_items2 <- c(
  "X6..Ich.bin.davon.überzeugt..dass.homöopathische.Mittel.bei.der.Heilung.von.Krankheiten.helfen.können..",
  "X12..Ich.habe.bereits einen Heilpraktiker oder Heilpraktikerin aufgesucht.",
  "X13..Ich.vertraue darauf, dass Heilpraktikerinnen meinen Gesundheitszustand umfassend und ganzheitlich betrachten.",
  "X14..Bei gesundheitlichen Problemen meiner Familie ziehe ich es in Betracht, Heilpraktikerinnen hinzuzuziehen.",
  "X21..Ich.ziehe.es.vor..bei.leichten.Beschwerden.zuerst.Homöopathika.zu.nutzen..bevor.ich.konventionelle.Medikamente.einnehme.",
  "X22..Ich.vertraue auf die Wirkung von Homöopathika, weil sie gut zu meinem achtsamen Lebensstil passen.",
  "X23..Ich.würde.alternative.Heilmethoden.oder.esoterische.Praktiken..Homöopathie..Chiropraktik..Kristallheilung..Pendeln.etc...bei.meinen.Kindern.anwenden..wenn.sie.krank.sind.",
  "X25..Ich.bevorzuge.es..zu.einer.Heilpraktikerin.zu.gehen..anstatt.konventionelle.medizinische.Hilfe.zu.suchen.",
  "X26..Ich.glaube..dass.Heilpraktikerinnen.oft.wirksamere.Lösungen.für.gesundheitliche Probleme.anbieten.als.Ärztinnen.",
  "X30..Ich.vertraue.auf.alternative.Heilmethoden..weil.ich.die.Erfahrung.gemacht.habe..dass.sie.wirken.",
  "X32..Alternative.Heilmethoden.passen.besser.zu.meinem.achtsamen.Lebensstil.und.meinen.persönlichen.Überzeugungen."
)

# Auswahl der Daten
setA2 <- get_cols(achtsamkeit_items)
setB2 <- get_cols(cam_items2)

# Nur vollständige Fälle behalten
cca2_data <- na.omit(cbind(setA2, setB2))

# Entfernen von konstanten Variablen
X2 <- drop_const_cols(cca2_data[, colnames(setA2), drop = FALSE])
Y2 <- drop_const_cols(cca2_data[, colnames(setB2), drop = FALSE])

# CCA durchführen
cca2_model <- cca(Y2, X2)
summary2 <- summary(cca2_model)

# Signifikanzprüfung
df2_sig <- data.frame(
  CV = names(summary2$corr),
  cancor = summary2$corr,
  p.value = pchisq(summary2$chisq, df = summary2$df, lower.tail = FALSE),
  Signifikant = ifelse(pchisq(summary2$chisq, df = summary2$df, lower.tail = FALSE) < 0.05, "ja", "nein")
)
write.csv(df2_sig, file.path(out_tab,"cca2_signifikanz.csv"), row.names = FALSE)

# Visualisierungen CCA2
p2 <- ggplot(df2_sig, aes(x = CV, y = cancor, fill = Signifikant)) +
  geom_col() + theme_minimal() +
  labs(title = "Korrelation Achtsamkeit & CAM-Nutzung", x = "Kanonische Variate", y = "Korrelation (R[c])")
ggsave(file.path(out_fig,"cca2_cancor.png"), p2, width = 7, height = 5, dpi = 300)

p2b <- ggplot(df2_sig, aes(x = CV, y = p.value, group = 1)) +
  geom_point(size = 3) + geom_line() +
  geom_hline(yintercept = 0.05, linetype = "dashed", color = "red") +
  theme_minimal() +
  labs(title = "Signifikanz der CVs – Achtsamkeit & CAM", x = "Kanonische Variate", y = "p-Wert")
ggsave(file.path(out_fig,"cca2_pvalues.png"), p2b, width = 7, height = 5, dpi = 300)

# Loadings CCA2
x_loadings2 <- as.data.frame(summary2$xstructcorr[, 1, drop = FALSE]); x_loadings2$Set <- "Achtsamkeit"; x_loadings2$Variable <- rownames(x_loadings2); names(x_loadings2)[1] <- "Loading"
y_loadings2 <- as.data.frame(summary2$ystructcorr[, 1, drop = FALSE]); y_loadings2$Set <- "CAM";          y_loadings2$Variable <- rownames(y_loadings2); names(y_loadings2)[1] <- "Loading"
cv1_all_2 <- rbind(x_loadings2, y_loadings2)
cv1_all_2 <- merge(cv1_all_2, label_map, by = "Variable", all.x = TRUE)

p2c <- ggplot(cv1_all_2, aes(x = reorder(Kurzlabel, Loading), y = Loading, fill = Set)) +
  geom_col() + coord_flip() + theme_minimal() +
  labs(title = "Kanonische Loadings: Achtsamkeit & CAM", x = "", y = "Loadings")
ggsave(file.path(out_fig,"cca2_loadings_cv1.png"), p2c, width = 7, height = 7, dpi = 300)

# ===========================================================
# ABSCHNITT 3: Zusammenhang zwischen Medizinskepsis und CAM-Nutzung
# ===========================================================

# Items Medizinskepsis (Set A)
medsk_items <- c(
  "X17..Ich.hinterfrage.medizinische.Behandlungen.und.Therapien.kritisch.",
  "X18..Ich.glaube..dass.konventionelle.Medizin.häufig.nur.Symptome.behandelt.und.nicht.die.Ursache.von.Krankheiten."
)

# Items CAM (Set B)
cam_items3 <- c(
  "X6..Ich.bin.davon.überzeugt..dass.homöopathische.Mittel.bei.der.Heilung.von.Krankheiten.helfen.können..",
  "X22..Ich.vertraue auf die Wirkung von Homöopathika, weil sie gut zu meinem achtsamen Lebensstil passen.",
  "X28..Ich.benutze Homöopathika, weil sie leichter erhältlich sind als herkömmliche Medikamente.",
  "X29..Ich.glaube.an.alternative.Heilmethoden, weil ich konventionellen Methoden oft skeptisch gegenüberstehe.",
  "X30..Ich.vertraue auf alternative Heilmethoden, weil ich die Erfahrung gemacht habe, dass sie wirken.",
  "X31..Ich.vertraue auf alternative Heilmethoden, weil ich sie für natürlicher und weniger schädlich halte als klassische Medikamente."
)

# Auswahl der Daten
setA3 <- get_cols(medsk_items)
setB3 <- get_cols(cam_items3)

# Vollständige Fälle behalten
cca3_data <- na.omit(cbind(setA3, setB3))

# Entfernen konstanter Variablen
X3 <- drop_const_cols(cca3_data[, colnames(setA3), drop = FALSE])
Y3 <- drop_const_cols(cca3_data[, colnames(setB3), drop = FALSE])

# CCA durchführen
cca3_model <- cca(Y3, X3)
summary3 <- summary(cca3_model)

# Signifikanzprüfung
df3_sig <- data.frame(
  CV = names(summary3$corr),
  cancor = summary3$corr,
  p.value = pchisq(summary3$chisq, df = summary3$df, lower.tail = FALSE),
  Signifikant = ifelse(pchisq(summary3$chisq, df = summary3$df, lower.tail = FALSE) < 0.05, "ja", "nein")
)
write.csv(df3_sig, file.path(out_tab,"cca3_signifikanz.csv"), row.names = FALSE)

# Visualisierungen CCA3
p3 <- ggplot(df3_sig, aes(x = CV, y = cancor, fill = Signifikant)) +
  geom_col() + theme_minimal() +
  labs(title = "Korrelation Medizinskepsis & CAM-Nutzung", x = "Kanonische Variate", y = "Korrelation (R[c])")
ggsave(file.path(out_fig,"cca3_loadings_cv1.png"), p3c, width = 7, height = 7, dpi = 300)

# ===========================================================
# Speichern der Dimensionstabellen für alle drei Analysen
# ===========================================================
for (i in 1:3) {
  s <- get(paste0("summary", i))  # jeweilige CCA-Zusammenfassung
  n <- nrow(get(paste0("X", i)))  # Anzahl Beobachtungen
  p <- ncol(get(paste0("X", i)))  # Anzahl Variablen im Prädiktor-Set
  q <- ncol(get(paste0("Y", i)))  # Anzahl Variablen im Kriteriums-Set
  
  dims <- data.frame(n = n, p = p, q = q)
  write.csv(dims, file.path(out_tab, paste0("cca",i,"_dimensionen.csv")), row.names = FALSE)
}
