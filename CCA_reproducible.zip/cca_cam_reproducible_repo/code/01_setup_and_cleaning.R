# -----------------------------------------------------------
# Lade benötigte Pakete
# -----------------------------------------------------------
library(ggplot2)  # Paket für Datenvisualisierung
library(reshape2) # Paket zur Umformung von Daten (long/wide), hier evtl. für spätere Analysen

# -----------------------------------------------------------
# Pfad zur Rohdatendatei definieren
# -----------------------------------------------------------
data_path <- file.path("data","raw","Daten_Fragebogen_aktuell.csv")  # Plattformunabhängiger Pfad

# Überprüfen, ob die Datei existiert. Stoppt das Skript, falls nicht
stopifnot(file.exists(data_path))

# -----------------------------------------------------------
# Einlesen der CSV-Datei in ein Dataframe
# -----------------------------------------------------------
df <- read.csv(data_path, stringsAsFactors = FALSE)  # Zeichenketten bleiben Zeichenketten

# -----------------------------------------------------------
# Umwandlung von Textantworten in numerische Werte
# -----------------------------------------------------------
df[] <- lapply(df, function(x) {
  # Nur Zeichenketten bearbeiten
  if (is.character(x)) {
    # Textantworten auf einer Likert-Skala in Zahlen umwandeln
    x <- gsub("trifft überhaupt nicht zu", "1", x, fixed = TRUE)
    x <- gsub("trifft nicht zu", "0.66", x, fixed = TRUE)
    x <- gsub("trifft etwas zu", "0.33", x, fixed = TRUE)
    x <- gsub("trifft zu", "0", x, fixed = TRUE)
  }
  # Versuch, die Spalte in numerisch umzuwandeln, unterdrückt Warnungen bei NAs
  suppressWarnings(as.numeric(x))
})

# -----------------------------------------------------------
# Funktion: Entfernt Spalten, die nur einen einzigen Wert enthalten
# (keine Varianz, z.B. konstante Spalten)
# -----------------------------------------------------------
drop_const_cols <- function(d) {
  d[, sapply(d, function(x) length(unique(na.omit(x))) > 1), drop = FALSE]
}

# -----------------------------------------------------------
# Einlesen des Codebooks zur Zuordnung von Variablenlabels
# -----------------------------------------------------------
label_map <- read.csv("CODEBOOK.csv", stringsAsFactors = FALSE)

# -----------------------------------------------------------
# Auswahl der Variablen, die auch im Dataframe vorhanden sind
# -----------------------------------------------------------
kern_vars <- label_map$Variable                 # alle Variablen aus Codebook
kern_vars <- kern_vars[kern_vars %in% names(df)]  # nur Variablen, die in df existieren

# -----------------------------------------------------------
# Berechnung von deskriptiven Statistiken für die Kernvariablen
# -----------------------------------------------------------
desc <- data.frame(
  Variable = kern_vars,
  N   = sapply(df[kern_vars], function(x) sum(!is.na(x))),        # Anzahl der nicht fehlenden Werte
  M   = sapply(df[kern_vars], function(x) mean(x, na.rm=TRUE)),   # Mittelwert
  SD  = sapply(df[kern_vars], function(x) sd(x, na.rm=TRUE)),     # Standardabweichung
  Min = sapply(df[kern_vars], function(x) min(x, na.rm=TRUE)),    # Minimalwert
  Max = sapply(df[kern_vars], function(x) max(x, na.rm=TRUE))     # Maximalwert
)

# -----------------------------------------------------------
# Speichern der deskriptiven Statistik als CSV-Datei
# -----------------------------------------------------------
write.csv(desc, file.path("outputs","tables","deskriptiv.csv"), row.names = FALSE)
