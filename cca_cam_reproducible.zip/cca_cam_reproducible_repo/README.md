# Repro-Repo: CCA zu Astrologie, Achtsamkeit, Medizinskepsis und CAM-Nutzung

Dieses Repository enthält **Daten** und **R-Code**, um die in der Arbeit angewandten kanonischen Korrelationsanalysen (KKA) mit allen Abbildungen und Tabellen zu **reproduzieren**.

## Struktur
```
.
data/
    daten_fragebogen.csv
code/
    00_run_all.R
    01_cleaning.R
    02_cca_models.R
    original_rmd/
        cca.Rmd
        CCA sets 2.Rmd
├── data/
│   └── raw/
│       └── Daten_Fragebogen_aktuell.csv
├── outputs/
│   ├── figures/
│   └── tables/
├── CODEBOOK.csv
├── LICENSE
└── README.md
```

## Voraussetzungen
- R (≥ 4.1 empfohlen)
- R-Pakete: `yacca`, `CCA`, `CCP`, `ggplot2`, `reshape2`

### Installation der Pakete
Führe einmal:
```r
source("code/00_run_all.R")
```
oder manuell:
```r
install.packages(c("yacca","CCA","CCP","ggplot2","reshape2"))
```

## Reproduktion
1. Repository klonen oder ZIP herunterladen und entpacken.
2. R-Arbeitsverzeichnis auf das Repo setzen (`setwd(...)`).
3. Ausführen:
```r
source("code/00_run_all.R")
```
Die Skripte lesen `data/raw/Daten_Fragebogen_aktuell.csv`, führen alle CCAs aus und schreiben **Abbildungen** nach `outputs/figures/` sowie **Tabellen** nach `outputs/tables/`.

## Hinweise zu Variablen & Kodierung
- Siehe `CODEBOOK.csv` für Item-Labels.
- Die im Manuskript verwendete Notation:
  - **Kanonische Variate (CV)** für die paarweise linearen Kombinationen.
  - **Kanonische Korrelation** \(R_c\) bezeichnet die Korrelation zwischen den beiden CVs einer Funktion.
  - **Kanonische Funktion** = Paar von CVs (eine pro Set) inkl. zugehörigem \(R_c\).

