req <- c("yacca","CCA","CCP","ggplot2","reshape2")
inst <- req[!(req %in% installed.packages()[, "Package"])]
if (length(inst) > 0) install.packages(inst, dependencies = TRUE)

source("code/01_setup_and_cleaning.R")
source("code/02_cca_models.R")

message("Fertig. Abbildungen unter outputs/figures/, Tabellen unter outputs/tables/.")
