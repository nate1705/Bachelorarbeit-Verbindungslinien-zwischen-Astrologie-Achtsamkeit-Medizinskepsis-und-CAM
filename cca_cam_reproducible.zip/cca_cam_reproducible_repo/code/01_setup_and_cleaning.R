library(ggplot2)
library(reshape2)

data_path <- file.path("data","raw","Daten_Fragebogen_aktuell.csv")
stopifnot(file.exists(data_path))

df <- read.csv(data_path, stringsAsFactors = FALSE)

df[] <- lapply(df, function(x) {
  if (is.character(x)) {
    x <- gsub("trifft überhaupt nicht zu", "1", x, fixed = TRUE)
    x <- gsub("trifft nicht zu", "0.66", x, fixed = TRUE)
    x <- gsub("trifft etwas zu", "0.33", x, fixed = TRUE)
    x <- gsub("trifft zu", "0", x, fixed = TRUE)
  }
  suppressWarnings(as.numeric(x))
})

drop_const_cols <- function(d) {
  d[, sapply(d, function(x) length(unique(na.omit(x))) > 1), drop = FALSE]
}

label_map <- read.csv("CODEBOOK.csv", stringsAsFactors = FALSE)
kern_vars <- label_map$Variable
kern_vars <- kern_vars[kern_vars %in% names(df)]
desc <- data.frame(
  Variable = kern_vars,
  N = sapply(df[kern_vars], function(x) sum(!is.na(x))),
  M = sapply(df[kern_vars], function(x) mean(x, na.rm=TRUE)),
  SD = sapply(df[kern_vars], function(x) sd(x, na.rm=TRUE)),
  Min = sapply(df[kern_vars], function(x) min(x, na.rm=TRUE)),
  Max = sapply(df[kern_vars], function(x) max(x, na.rm=TRUE))
)
write.csv(desc, file.path("outputs","tables","deskriptiv.csv"), row.names = FALSE)
